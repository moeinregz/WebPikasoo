// این فایل با ساختار واقعی جدول‌های BarNo_1405 کامل شده است:
//   Factors, FactorsGir, FactorsRiz, FactorsInfo, Moshtarian, Prices
// بقیه پروژه (index.js) را دست نزنید.
//
// روش کار: به‌جای ستون تاریخ، از FactorsGir.ID به‌عنوان یک مارکر افزایشی
// (auto-increment) استفاده می‌کنیم - یعنی فقط شرکت‌هایی که ID‌شان از
// آخرین رکورد sync‌شده بزرگ‌تر است خوانده می‌شوند. کاملاً read-only است؛
// هیچ‌چیزی داخل دیتابیس شما تغییر داده نمی‌شود.

const DATABASE = "BarNo_1405";

// ---------------------------------------------------------------------
// ۱) کوئری سرفصل: هر ردیف = یک محموله (FactorsGir) به همراه اطلاعات
// فاکتور سرفصلش (Factors)، نام واقعی فرستنده/مشتری (Moshtarian)، نام
// واقعی شهر مقصد (cities) و تاریخ واقعی تحویل (FactorsInfo)
// ---------------------------------------------------------------------
function buildHeaderQuery() {
  return `
    SELECT TOP 200
      g.ID, g.Sal, g.Shomareh, g.ShResid, g.NameGir, g.Address, g.OutOfCity,
      g.Mobile, g.Phone, g.CdShahr, g.CdBarbary, g.TypeKerayeh, g.TypeTahvil,
      g.BimehType, g.IsIrad, g.Sharh,
      f.ID AS FactorID, f.Tarikh, f.CdFrst, f.FactorUnique,
      m.Name AS CdFrstName,
      c.Name AS CityName,
      i.TarikhReceived AS TarikhTahvil
    FROM ${DATABASE}.dbo.FactorsGir g
    LEFT JOIN ${DATABASE}.dbo.Factors f
      ON f.Sal = g.Sal AND f.Shomareh = g.Shomareh
    LEFT JOIN ${DATABASE}.dbo.Moshtarian m
      ON m.Code = f.CdFrst
    LEFT JOIN ${DATABASE}.dbo.cities c
      ON c.Code = g.CdShahr
    LEFT JOIN ${DATABASE}.dbo.FactorsInfo i
      ON i.Sal = g.Sal AND i.Shomareh = g.Shomareh AND i.ShResid = g.ShResid
    WHERE g.ID > @lastId
    ORDER BY g.ID ASC
  `;
}

// نام ستونی که به‌عنوان مارکر افزایشی استفاده می‌شود (باید در نتیجه‌ی
// buildHeaderQuery برگردد).
const LAST_SYNC_COLUMN = "ID";

// ---------------------------------------------------------------------
// ۲) کوئری اقلام: برای هر محموله، ردیف‌های FactorsRiz مربوطش + نام واقعی
// کالا (Kala) + مبلغ کرایه‌ی متناظر از جدول Prices (که به ریال ذخیره شده
// - برای همین ÷۱۰ می‌کنیم تا تومان بشود).
//
// Prices بر اساس (CodeErsal = کد فرستنده/مشتری، همان Moshtarian.Code) +
// کد کالا + شهر مقصد، و معتبر بودن در بازه‌ی تاریخ فاکتور مچ می‌شود.
// CodeShahr می‌تواند 0 باشد یعنی «همه‌ی شهرها» - اول دنبال یک قیمت
// مخصوصِ همین شهر می‌گردیم و اگر پیدا نشد، قیمت عمومی (شهر=0) را
// برمی‌داریم.
// ---------------------------------------------------------------------
function buildItemsQuery() {
  return `
    SELECT
      r.CdKala, r.CdZirKala, r.Tedad, r.FiVahed, r.Kol, r.KolBarbary, r.ArzeshYek,
      k.Name AS KalaName,
      pr.Mablagh AS PriceMablaghRial
    FROM ${DATABASE}.dbo.FactorsRiz r
    LEFT JOIN ${DATABASE}.dbo.Kala k
      ON k.Code = r.CdKala
    OUTER APPLY (
      SELECT TOP 1 p.Mablagh
      FROM ${DATABASE}.dbo.Prices p
      WHERE p.CodeErsal = @codeErsal
        AND p.CodeKala = r.CdKala
        AND ISNULL(p.CodeZirKala, 0) = ISNULL(r.CdZirKala, 0)
        AND p.AzTarikh <= @tarikh AND p.TaTarikh >= @tarikh
        AND p.CodeShahr IN (@codeShahr, 0)
      ORDER BY CASE WHEN p.CodeShahr = @codeShahr THEN 0 ELSE 1 END
    ) pr
    WHERE r.Sal = @sal AND r.Shomareh = @shomareh AND r.ShResid = @shresid
  `;
}

// ارزش کل کالا (برای بیمه و نمایش) - نه از جمع ستون Kol، بلکه از عدد
// رسمی ثبت‌شده در FactorsPool.ArzeshKolKala برای همین گیرنده.
function buildGoodsValueQuery() {
  return `
    SELECT ArzeshKolKala
    FROM ${DATABASE}.dbo.FactorsPool
    WHERE Sal = @sal AND Shomareh = @shomareh AND ShResid = @shresid
  `;
}

// نوع بیمه (عادی/طلایی) از روی BimehType سرفصل - مبلغش دیگر اینجا محاسبه
// نمی‌شود؛ فقط نوعش فرستاده می‌شود و خود سرور طبق فرمول ثابت
// (ارزش کالا ÷ ۱٬۰۰۰٬۰۰۰ × نرخ) حسابش می‌کند.
function insuranceTypeFromHeader(header) {
  return Number(header.BimehType) === 2 ? "GOLDEN" : "NORMAL"; // TODO: مقدار دقیق BimehType را با نمونه‌داده تایید کنید
}

// تبدیل رقم‌های فارسی (۰-۹) به رقم‌های انگلیسی، چون فیلدهای تاریخ توی
// SQL Server با رقم فارسی ذخیره شده‌اند و JavaScript آن‌ها را نمی‌فهمد.
function persianDigitsToEnglish(str) {
  const persianDigits = "۰۱۲۳۴۵۶۷۸۹";
  return String(str).replace(/[۰-۹]/g, (ch) => String(persianDigits.indexOf(ch)));
}

// تبدیل تاریخ شمسی (جلالی) به میلادی - الگوریتم استاندارد و شناخته‌شده.
function jalaliToGregorian(jy, jm, jd) {
  let gy;
  if (jy > 979) {
    gy = 1600;
    jy -= 979;
  } else {
    gy = 621;
  }
  let days = 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + 78 + jd +
    (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const salA = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm;
  for (gm = 0; gm < 13; gm++) {
    const v = salA[gm];
    if (gd <= v) break;
    gd -= v;
  }
  return [gy, gm, gd];
}

// رشته‌ی تاریخ شمسی (مثل «۱۴۰۵/۰۱/۱۷» یا حتی «1405/1/17») را به رشته‌ی
// تاریخ میلادی ISO (قابل فهم برای Prisma/JavaScript) تبدیل می‌کند.
// اگر فرمت شناخته‌نشد یا خالی بود، undefined برمی‌گرداند تا کل فاکتور رد نشود.
function toISODate(jalaliStr) {
  if (!jalaliStr) return undefined;
  const normalized = persianDigitsToEnglish(jalaliStr).trim();
  const match = normalized.match(/^(\d{3,4})[\/-](\d{1,2})[\/-](\d{1,2})/);
  if (!match) return undefined;
  const jy = Number(match[1]);
  const jm = Number(match[2]);
  const jd = Number(match[3]);
  if (!jy || !jm || !jd || jm > 12 || jd > 31) return undefined;
  const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
  return `${gy}-${String(gm).padStart(2, "0")}-${String(gd).padStart(2, "0")}`;
}

// ---------------------------------------------------------------------
// ۳) نگاشت به بدنه‌ی درخواست POST /api/partner/shipments
// ---------------------------------------------------------------------
// TODO (بعداً دقیق‌تر می‌کنیم):
//   - TypeKerayeh / TypeTahvil -> عددی هستند؛ باید بفهمیم کدام عدد یعنی
//     چه (مثلاً ۱=پیش‌کرایه، ۲=پس‌کرایه)؛ فعلاً حدس منطقی زده شده.
function mapToShipment(header, items, goodsValue) {
  const freightFromPrices = items.reduce((sum, it) => sum + (Number(it.PriceMablaghRial) || 0), 0);
  return {
    invoiceNumber: `${header.Sal}-${header.Shomareh}`,
    senderName: header.CdFrstName ? header.CdFrstName.trim() : `مشتری کد ${header.CdFrst}`,
    notes: header.Sharh || undefined,
    parcels: [
      {
        receiverName: header.NameGir,
        receiverPhone: header.Mobile || header.Phone,
        receiverCity: header.CityName ? header.CityName.trim() : (header.CdShahr ? `شهر کد ${header.CdShahr}` : undefined),
        receiverAddress: header.Address,
        items: items.map((it) => ({
          title: it.KalaName && it.KalaName.trim() ? it.KalaName.trim() : `کالا کد ${it.CdKala}`,
          quantity: it.Tedad,
        })),
        goodsValue: goodsValue || undefined,
        // Prices.Mablagh به ریال است؛ سایت با تومان کار می‌کند - برای همین ÷۱۰.
        freightCost: freightFromPrices ? Math.round(freightFromPrices / 10) : undefined,
        insuranceType: insuranceTypeFromHeader(header),
        // TODO: مقدار دقیق TypeKerayeh را با نمونه‌داده بررسی و اصلاح کنید
        paymentMethod: Number(header.TypeKerayeh) === 2 ? "POSTPAID" : "PREPAID",
        deliveryMethod: Number(header.OutOfCity) === 1 ? "AT_ADDRESS" : "AT_TERMINAL",
        hasIssue: Boolean(header.IsIrad),
        promisedDeliveryDate: toISODate(header.TarikhTahvil),
      },
    ],
  };
}

// یک فاکتور (Sal+Shomareh) می‌تواند چند گیرنده (چند ردیف FactorsGir)
// داشته باشد. این تابع همه‌ی گیرنده‌های یک فاکتور را با هم در قالب یک
// درخواست واحد (با آرایه‌ی receivers) می‌سازد - چون سرور با شماره فاکتور
// یکتا کار می‌کند و فرستادن هر گیرنده در یک درخواست جدا باعث می‌شد فقط
// گیرنده‌ی اول ثبت شود و بقیه به‌عنوان «تکراری» رد شوند.
// group: آرایه‌ای از { header, items } که همه Sal+Shomareh یکسان دارند.
function mapToShipmentGroup(group) {
  const first = group[0].header;
  return {
    invoiceNumber: `${first.Sal}-${first.Shomareh}`,
    senderName: first.CdFrstName ? first.CdFrstName.trim() : `مشتری کد ${first.CdFrst}`,
    notes: first.Sharh || undefined,
    receivers: group.map(({ header, items, goodsValue }) => {
      const freightFromPrices = items.reduce((sum, it) => sum + (Number(it.PriceMablaghRial) || 0), 0);
      return {
        receiverName: header.NameGir,
        receiverPhone: header.Mobile || header.Phone,
        receiverCity: header.CityName ? header.CityName.trim() : (header.CdShahr ? `شهر کد ${header.CdShahr}` : undefined),
        receiverAddress: header.Address,
        items: items.map((it) => ({
          title: it.KalaName && it.KalaName.trim() ? it.KalaName.trim() : `کالا کد ${it.CdKala}`,
          quantity: it.Tedad,
        })),
        goodsValue: goodsValue || undefined,
        // Prices.Mablagh به ریال است؛ سایت با تومان کار می‌کند - برای همین ÷۱۰.
        freightCost: freightFromPrices ? Math.round(freightFromPrices / 10) : undefined,
        insuranceType: insuranceTypeFromHeader(header),
        paymentMethod: Number(header.TypeKerayeh) === 2 ? "POSTPAID" : "PREPAID",
        deliveryMethod: Number(header.OutOfCity) === 1 ? "AT_ADDRESS" : "AT_TERMINAL",
        hasIssue: Boolean(header.IsIrad),
        promisedDeliveryDate: toISODate(header.TarikhTahvil),
      };
    }),
  };
}

module.exports = { buildHeaderQuery, buildItemsQuery, buildGoodsValueQuery, mapToShipment, mapToShipmentGroup, LAST_SYNC_COLUMN };

// ---------------------------------------------------------------------
// ۴) شناسه‌ی «شرکت» برای هر رکورد سرفصل
// ---------------------------------------------------------------------
// به‌جای نگهداری دستی نگاشت کد->کلید API (که با صدها مشتری غیرعملی
// است)، index.js خودش با استفاده از این دو مقدار به‌صورت خودکار شرکت
// متناظر را در پنل پیدا یا ایجاد می‌کند (از طریق
// POST /api/partner/companies/auto). فقط باید بگوییم کد و نام هر مشتری
// از کجای رکورد خوانده شود.
function companyIdentityForHeader(header) {
  if (header.CdFrst == null) return null;
  return {
    externalCode: String(header.CdFrst),
    name: header.CdFrstName ? header.CdFrstName.trim() : `مشتری کد ${header.CdFrst}`,
  };
}

module.exports.companyIdentityForHeader = companyIdentityForHeader;
