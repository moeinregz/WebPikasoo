require("dotenv").config();
const fs = require("fs");
const path = require("path");
const sql = require("mssql");
const axios = require("axios");
const cron = require("node-cron");
const { buildHeaderQuery, buildItemsQuery, buildGoodsValueQuery, mapToShipmentGroup, LAST_SYNC_COLUMN, companyIdentityForHeader } = require("./config");

const STATE_FILE = path.join(__dirname, "state.json");
const COMPANY_CACHE_FILE = path.join(__dirname, "companies-cache.json");
const NEW_LOGINS_FILE = path.join(__dirname, "new-company-logins.csv");

const sqlConfig = {
  server: process.env.SQL_SERVER,
  port: Number(process.env.SQL_PORT) || 1433,
  database: process.env.SQL_DATABASE,
  user: process.env.SQL_USER,
  password: process.env.SQL_PASSWORD,
  options: {
    encrypt: process.env.SQL_ENCRYPT === "true",
    trustServerCertificate: true,
  },
};

const apiClient = axios.create({
  baseURL: process.env.API_BASE_URL,
  timeout: 15000,
});

function loadState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
  } catch {
    return { lastId: 0 };
  }
}

function saveState(state) {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

// نگاشت محلی externalCode -> apiKey، تا هر بار مجبور نباشیم دوباره از
// پنل بپرسیم که آیا این شرکت قبلاً ساخته شده یا نه.
function loadCompanyCache() {
  try {
    return JSON.parse(fs.readFileSync(COMPANY_CACHE_FILE, "utf8"));
  } catch {
    return {};
  }
}

function saveCompanyCache(cache) {
  fs.writeFileSync(COMPANY_CACHE_FILE, JSON.stringify(cache, null, 2));
}

function log(...args) {
  console.log(`[${new Date().toISOString()}]`, ...args);
}

// داده‌ی قدیمی FoxPro گاهی کاراکترهای غیرمجاز (کنترلی/سوروگیت خراب) توی
// فیلدهای متنی دارد که درایور SQL Server موقع ساخت پارامتر رد می‌کند
// («Invalid string»). این تابع چنین کاراکترهایی را قبل از ارسال حذف می‌کند.
function cleanSqlString(value) {
  if (value === null || value === undefined) return value;
  const str = String(value);
  // eslint-disable-next-line no-control-regex
  return str.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").replace(/[\uD800-\uDFFF]/g, "");
}

async function fetchItemsForHeader(pool, header) {
  const request = pool.request();
  request.input("sal", sql.NVarChar, cleanSqlString(header.Sal));
  request.input("shomareh", sql.NVarChar, cleanSqlString(header.Shomareh));
  request.input("shresid", sql.NVarChar, cleanSqlString(header.ShResid));
  // این پارامترها برای جوین با جدول Prices (پیدا کردن مبلغ کرایه) لازم‌اند.
  // CodeErsal طبق توضیح، همان کد فرستنده/مشتری (Moshtarian.Code) است.
  request.input("codeShahr", sql.NVarChar, cleanSqlString(header.CdShahr));
  request.input("codeErsal", sql.NVarChar, cleanSqlString(header.CdFrst));
  request.input("tarikh", sql.NVarChar, cleanSqlString(header.Tarikh));
  const result = await request.query(buildItemsQuery());
  return result.recordset || [];
}

// ارزش کل رسمی کالا برای این گیرنده را از FactorsPool می‌خواند (نه از
// جمع‌کردن دستی ستون Kol توی اقلام).
async function fetchGoodsValueForHeader(pool, header) {
  const request = pool.request();
  request.input("sal", sql.NVarChar, cleanSqlString(header.Sal));
  request.input("shomareh", sql.NVarChar, cleanSqlString(header.Shomareh));
  request.input("shresid", sql.NVarChar, cleanSqlString(header.ShResid));
  const result = await request.query(buildGoodsValueQuery());
  const row = (result.recordset || [])[0];
  return row ? Number(row.ArzeshKolKala) || 0 : 0;
}

// شرکت متناظر این رکورد را در پنل پیدا می‌کند یا (اگر اولین‌بار است)
// می‌سازد، و کلید API‌اش را برمی‌گرداند. نتیجه در فایل محلی کش می‌شود تا
// دفعات بعد نیازی به تماس مجدد نباشد.
async function resolveApiKey(companyCache, identity) {
  if (companyCache[identity.externalCode]) return companyCache[identity.externalCode];

  const { data } = await apiClient.post(
    "/api/partner/companies/auto",
    { externalCode: identity.externalCode, name: identity.name },
    { headers: { "X-Provision-Secret": process.env.SYNC_PROVISION_SECRET } }
  );

  companyCache[identity.externalCode] = data.apiKey;
  saveCompanyCache(companyCache);

  if (data.created && data.login) {
    const isNewFile = !fs.existsSync(NEW_LOGINS_FILE);
    const line = `${new Date().toISOString()},${identity.externalCode},"${identity.name}",${data.login.username},${data.login.password}\n`;
    if (isNewFile) fs.appendFileSync(NEW_LOGINS_FILE, "created_at,external_code,company_name,username,password\n");
    fs.appendFileSync(NEW_LOGINS_FILE, line);
    log(`🆕 شرکت جدید ساخته شد: «${identity.name}» - اطلاعات ورود در ${NEW_LOGINS_FILE} ذخیره شد.`);
  }

  return data.apiKey;
}

async function syncOnce() {
  const state = loadState();
  const companyCache = loadCompanyCache();
  log(`شروع sync (آخرین ID قبلی: ${state.lastId ?? 0})`);

  let pool;
  try {
    pool = await sql.connect(sqlConfig);
  } catch (err) {
    log("❌ اتصال به SQL Server ناموفق بود:", err.message);
    return;
  }

  try {
    const headerRequest = pool.request();
    headerRequest.input("lastId", sql.BigInt, state.lastId || 0);
    const headerResult = await headerRequest.query(buildHeaderQuery());
    const headers = headerResult.recordset || [];

    if (headers.length === 0) {
      log("محموله‌ی جدیدی برای sync وجود نداشت.");
      return;
    }

    log(`${headers.length} محموله‌ی جدید پیدا شد. در حال ارسال به پنل...`);

    // گروه‌بندی بر اساس شماره فاکتور (Sal+Shomareh) - چون یک فاکتور
    // می‌تواند چند گیرنده (چند ردیف FactorsGir) داشته باشد و همه باید در
    // یک درخواست واحد فرستاده شوند، وگرنه فقط گیرنده‌ی اول ثبت می‌شود و
    // بقیه به‌عنوان «تکراری» رد می‌شوند.
    const groups = new Map();
    const groupOrder = [];
    for (const header of headers) {
      const key = `${header.Sal}|${header.Shomareh}`;
      if (!groups.has(key)) {
        groups.set(key, []);
        groupOrder.push(key);
      }
      groups.get(key).push(header);
    }

    let successCount = 0; // تعداد فاکتور (نه گیرنده) ثبت‌شده
    let skipCount = 0;
    let failCount = 0;

    for (const key of groupOrder) {
      const groupHeaders = groups.get(key);
      const maxIdInGroup = Math.max(...groupHeaders.map((h) => h[LAST_SYNC_COLUMN]));
      const identity = companyIdentityForHeader(groupHeaders[0]);

      if (!identity) {
        log(`⚠️  فاکتور ${key} کد فرستنده ندارد - رد شد.`);
        state.lastId = maxIdInGroup;
        continue;
      }

      try {
        const apiKey = await resolveApiKey(companyCache, identity);
        const group = [];
        for (const header of groupHeaders) {
          const items = await fetchItemsForHeader(pool, header);
          const goodsValue = await fetchGoodsValueForHeader(pool, header);
          group.push({ header, items, goodsValue });
        }
        const payload = mapToShipmentGroup(group);
        await apiClient.post("/api/partner/shipments", payload, { headers: { "X-API-Key": apiKey } });
        successCount++;
      } catch (err) {
        if (err.response?.status === 409) {
          // این شماره فاکتور قبلاً ثبت شده - بی‌خطر است، رد می‌شویم.
          skipCount++;
        } else if (err.code === "EPARAM" || err.code === "EREQUEST") {
          // خطای داده‌ی خراب سمت SQL - مشکل دائمی همین فاکتور است، نه
          // موقتی. اگر متوقف شویم، بقیه‌ی فاکتورهای سالم هم هیچ‌وقت
          // sync نمی‌شوند؛ پس فقط همین یکی را رد می‌کنیم و ادامه می‌دهیم.
          skipCount++;
          log("⚠️  فاکتور (", key, ") به‌خاطر داده‌ی نامعتبر رد شد و ادامه یافت:", err.message);
        } else {
          failCount++;
          log("⚠️  ارسال فاکتور", key, "ناموفق بود:", err.response?.data?.error || err.message);
          // این فاکتور را sync نشده در نظر می‌گیریم و متوقف می‌شویم تا
          // مارکر جلوتر از این نرود و در دور بعد دوباره تلاش شود.
          break;
        }
      }

      state.lastId = maxIdInGroup;
    }

    saveState(state);
    log(`پایان sync -> موفق: ${successCount} فاکتور | تکراری/رد شده: ${skipCount} | ناموفق: ${failCount}`);
  } catch (err) {
    log("❌ خطا در حین sync:", err.message);
  } finally {
    await pool.close();
  }
}

async function main() {
  const runOnce = process.argv.includes("--once");

  if (runOnce) {
    await syncOnce();
    process.exit(0);
  }

  const interval = Number(process.env.SYNC_INTERVAL_MINUTES) || 5;
  log(`عامل همگام‌سازی شروع شد - هر ${interval} دقیقه یک‌بار اجرا می‌شود.`);

  await syncOnce(); // یک بار همین اول اجرا کن، بعد طبق زمان‌بندی
  cron.schedule(`*/${interval} * * * *`, syncOnce);
}

main();
